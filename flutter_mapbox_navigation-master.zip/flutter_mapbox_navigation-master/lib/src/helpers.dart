/// Checks if a num is 0 or null
bool isNullOrZero(num? val) {
  return val == 0.0 || val == null;
}
