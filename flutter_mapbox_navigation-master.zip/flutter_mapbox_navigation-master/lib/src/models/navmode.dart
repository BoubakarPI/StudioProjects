// ignore_for_file: public_member_api_docs

///Option to specify the mode of transportation.
@Deprecated('Use MapBoxNavigationMode instead')
enum NavigationMode { walking, cycling, driving, drivingWithTraffic }

///Option to specify the mode of transportation.
enum MapBoxNavigationMode { walking, cycling, driving, drivingWithTraffic }
