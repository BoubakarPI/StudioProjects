package com.eopeter.fluttermapboxnavigationexample

import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity: FlutterFragmentActivity() {
}
